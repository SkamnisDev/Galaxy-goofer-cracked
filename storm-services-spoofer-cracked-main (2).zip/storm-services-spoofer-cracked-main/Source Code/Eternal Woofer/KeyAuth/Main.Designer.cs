﻿namespace KeyAuth
{
	// Token: 0x02000007 RID: 7
	public partial class Main : global::System.Windows.Forms.Form
	{
		// Token: 0x06000079 RID: 121 RVA: 0x00006040 File Offset: 0x00004240
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			bool flag2 = flag;
			if (flag2)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600007A RID: 122 RVA: 0x0000607C File Offset: 0x0000427C
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::KeyAuth.Main));
			this.label1 = new global::System.Windows.Forms.Label();
			this.guna2BorderlessForm1 = new global::Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
			this.homeBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.settingsBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.siticoneControlBox1 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.siticoneControlBox2 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.guna2Button4 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button3 = new global::Guna.UI2.WinForms.Guna2Button();
			this.key = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.subscriptionDaysLabel = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.guna2Button6 = new global::Guna.UI2.WinForms.Guna2Button();
			this.hwidlabel = new global::System.Windows.Forms.Label();
			this.PANELhome = new global::Guna.UI2.WinForms.Guna2Panel();
			this.guna2Panel1 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.label12 = new global::System.Windows.Forms.Label();
			this.guna2Button1 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.label15 = new global::System.Windows.Forms.Label();
			this.label16 = new global::System.Windows.Forms.Label();
			this.createDate = new global::System.Windows.Forms.Label();
			this.label29 = new global::System.Windows.Forms.Label();
			this.label31 = new global::System.Windows.Forms.Label();
			this.label28 = new global::System.Windows.Forms.Label();
			this.label30 = new global::System.Windows.Forms.Label();
			this.label27 = new global::System.Windows.Forms.Label();
			this.guna2Button20 = new global::Guna.UI2.WinForms.Guna2Button();
			this.cleanPANEL = new global::Guna.UI2.WinForms.Guna2Panel();
			this.guna2Button19 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button18 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button16 = new global::Guna.UI2.WinForms.Guna2Button();
			this.siticoneControlBox7 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.guna2Panel3 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.label22 = new global::System.Windows.Forms.Label();
			this.guna2Button17 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label23 = new global::System.Windows.Forms.Label();
			this.label24 = new global::System.Windows.Forms.Label();
			this.label25 = new global::System.Windows.Forms.Label();
			this.label26 = new global::System.Windows.Forms.Label();
			this.siticoneControlBox8 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.SPOOFPANEL = new global::Guna.UI2.WinForms.Guna2Panel();
			this.guna2Panel4 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.label17 = new global::System.Windows.Forms.Label();
			this.guna2Button15 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label18 = new global::System.Windows.Forms.Label();
			this.label19 = new global::System.Windows.Forms.Label();
			this.label20 = new global::System.Windows.Forms.Label();
			this.label21 = new global::System.Windows.Forms.Label();
			this.guna2Button7 = new global::Guna.UI2.WinForms.Guna2Button();
			this.cleanBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.PANELhome.SuspendLayout();
			this.guna2Panel1.SuspendLayout();
			this.cleanPANEL.SuspendLayout();
			this.guna2Panel3.SuspendLayout();
			this.SPOOFPANEL.SuspendLayout();
			this.guna2Panel4.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Segoe UI Light", 10f);
			this.label1.ForeColor = global::System.Drawing.Color.White;
			this.label1.Location = new global::System.Drawing.Point(-1, 136);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(0, 19);
			this.label1.TabIndex = 22;
			this.label1.Click += new global::System.EventHandler(this.label1_Click);
			this.guna2BorderlessForm1.AnimationInterval = 100;
			this.guna2BorderlessForm1.AnimationType = global::Guna.UI2.WinForms.Guna2BorderlessForm.AnimateWindowType.AW_CENTER;
			this.guna2BorderlessForm1.BorderRadius = 30;
			this.guna2BorderlessForm1.ContainerControl = this;
			this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
			this.guna2BorderlessForm1.ResizeForm = false;
			this.guna2BorderlessForm1.TransparentWhileDrag = true;
			this.homeBTN.Animated = true;
			this.homeBTN.AnimatedGIF = true;
			this.homeBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.homeBTN.BorderColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.BorderRadius = 5;
			this.homeBTN.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.homeBTN.Checked = true;
			this.homeBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.homeBTN.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.homeBTN.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.homeBTN.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.homeBTN.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.homeBTN.FillColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.FocusedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.homeBTN.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.homeBTN.ForeColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.homeBTN.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("homeBTN.Image");
			this.homeBTN.Location = new global::System.Drawing.Point(27, 227);
			this.homeBTN.Name = "homeBTN";
			this.homeBTN.PressedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.homeBTN.Size = new global::System.Drawing.Size(35, 35);
			this.homeBTN.TabIndex = 46;
			this.homeBTN.UseTransparentBackground = true;
			this.homeBTN.Click += new global::System.EventHandler(this.homeBTN_Click);
			this.settingsBTN.Animated = true;
			this.settingsBTN.AnimatedGIF = true;
			this.settingsBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.settingsBTN.BorderColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.BorderRadius = 5;
			this.settingsBTN.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.settingsBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.settingsBTN.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.settingsBTN.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.settingsBTN.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.settingsBTN.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.settingsBTN.FillColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.FocusedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.settingsBTN.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.settingsBTN.ForeColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.settingsBTN.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("settingsBTN.Image");
			this.settingsBTN.Location = new global::System.Drawing.Point(27, 284);
			this.settingsBTN.Name = "settingsBTN";
			this.settingsBTN.PressedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.settingsBTN.Size = new global::System.Drawing.Size(35, 35);
			this.settingsBTN.TabIndex = 47;
			this.settingsBTN.UseTransparentBackground = true;
			this.settingsBTN.Click += new global::System.EventHandler(this.settingsBTN_Click);
			this.siticoneControlBox1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox1.BorderRadius = 10;
			this.siticoneControlBox1.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox1.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(232, 17, 35);
			this.siticoneControlBox1.HoveredState.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox1.HoveredState.Parent = this.siticoneControlBox1;
			this.siticoneControlBox1.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox1.Location = new global::System.Drawing.Point(918, 10);
			this.siticoneControlBox1.Name = "siticoneControlBox1";
			this.siticoneControlBox1.ShadowDecoration.Parent = this.siticoneControlBox1;
			this.siticoneControlBox1.Size = new global::System.Drawing.Size(30, 26);
			this.siticoneControlBox1.TabIndex = 1;
			this.siticoneControlBox1.Click += new global::System.EventHandler(this.siticoneControlBox1_Click);
			this.siticoneControlBox2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox2.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox2.BorderRadius = 10;
			this.siticoneControlBox2.ControlBoxType = global::Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
			this.siticoneControlBox2.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox2.HoveredState.Parent = this.siticoneControlBox2;
			this.siticoneControlBox2.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox2.Location = new global::System.Drawing.Point(882, 10);
			this.siticoneControlBox2.Name = "siticoneControlBox2";
			this.siticoneControlBox2.ShadowDecoration.Parent = this.siticoneControlBox2;
			this.siticoneControlBox2.Size = new global::System.Drawing.Size(30, 26);
			this.siticoneControlBox2.TabIndex = 2;
			this.siticoneControlBox2.Click += new global::System.EventHandler(this.siticoneControlBox2_Click);
			this.guna2Button4.Animated = true;
			this.guna2Button4.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.BorderColor = global::System.Drawing.Color.SeaShell;
			this.guna2Button4.BorderRadius = 7;
			this.guna2Button4.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button4.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button4.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button4.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button4.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button4.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button4.ForeColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.Location = new global::System.Drawing.Point(216, 290);
			this.guna2Button4.Name = "guna2Button4";
			this.guna2Button4.PressedColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.PressedDepth = 20;
			this.guna2Button4.Size = new global::System.Drawing.Size(323, 101);
			this.guna2Button4.TabIndex = 42;
			this.guna2Button4.Click += new global::System.EventHandler(this.guna2Button4_Click);
			this.guna2Button3.Animated = true;
			this.guna2Button3.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button3.BorderColor = global::System.Drawing.Color.SeaShell;
			this.guna2Button3.BorderRadius = 7;
			this.guna2Button3.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button3.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button3.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button3.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button3.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button3.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button3.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button3.Location = new global::System.Drawing.Point(216, 119);
			this.guna2Button3.Name = "guna2Button3";
			this.guna2Button3.PressedColor = global::System.Drawing.Color.Gainsboro;
			this.guna2Button3.PressedDepth = 20;
			this.guna2Button3.Size = new global::System.Drawing.Size(323, 98);
			this.guna2Button3.TabIndex = 41;
			this.guna2Button3.Click += new global::System.EventHandler(this.guna2Button3_Click_1);
			this.key.BackColor = global::System.Drawing.Color.Transparent;
			this.key.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.key.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.key.Location = new global::System.Drawing.Point(329, 364);
			this.key.Margin = new global::System.Windows.Forms.Padding(2);
			this.key.Name = "key";
			this.key.Size = new global::System.Drawing.Size(92, 17);
			this.key.TabIndex = 37;
			this.key.Text = "usernameLabel";
			this.key.TextAlignment = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.key.Click += new global::System.EventHandler(this.key_Click);
			this.subscriptionDaysLabel.BackColor = global::System.Drawing.Color.Transparent;
			this.subscriptionDaysLabel.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.subscriptionDaysLabel.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.subscriptionDaysLabel.Location = new global::System.Drawing.Point(223, 337);
			this.subscriptionDaysLabel.Margin = new global::System.Windows.Forms.Padding(2);
			this.subscriptionDaysLabel.Name = "subscriptionDaysLabel";
			this.subscriptionDaysLabel.Size = new global::System.Drawing.Size(69, 17);
			this.subscriptionDaysLabel.TabIndex = 38;
			this.subscriptionDaysLabel.Text = "expiryLabel";
			this.subscriptionDaysLabel.Click += new global::System.EventHandler(this.expiry_Click);
			this.guna2Button6.BorderRadius = 3;
			this.guna2Button6.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button6.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button6.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button6.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button6.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button6.FillColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.guna2Button6.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button6.ForeColor = global::System.Drawing.Color.Black;
			this.guna2Button6.Location = new global::System.Drawing.Point(609, 211);
			this.guna2Button6.Name = "guna2Button6";
			this.guna2Button6.Size = new global::System.Drawing.Size(72, 19);
			this.guna2Button6.TabIndex = 53;
			this.guna2Button6.Text = "SHOW";
			this.guna2Button6.Click += new global::System.EventHandler(this.guna2Button6_Click);
			this.hwidlabel.AutoSize = true;
			this.hwidlabel.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.hwidlabel.ForeColor = global::System.Drawing.Color.White;
			this.hwidlabel.Location = new global::System.Drawing.Point(61, 211);
			this.hwidlabel.Name = "hwidlabel";
			this.hwidlabel.Size = new global::System.Drawing.Size(72, 19);
			this.hwidlabel.TabIndex = 51;
			this.hwidlabel.Text = "HIDDEN";
			this.hwidlabel.Click += new global::System.EventHandler(this.hwidlabel_Click);
			this.PANELhome.BackColor = global::System.Drawing.Color.Transparent;
			this.PANELhome.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("PANELhome.BackgroundImage");
			this.PANELhome.Controls.Add(this.guna2Panel1);
			this.PANELhome.Controls.Add(this.guna2Button6);
			this.PANELhome.Controls.Add(this.createDate);
			this.PANELhome.Controls.Add(this.hwidlabel);
			this.PANELhome.Controls.Add(this.label29);
			this.PANELhome.Controls.Add(this.label31);
			this.PANELhome.Controls.Add(this.label28);
			this.PANELhome.Controls.Add(this.label30);
			this.PANELhome.Controls.Add(this.label27);
			this.PANELhome.Controls.Add(this.guna2Button20);
			this.PANELhome.Location = new global::System.Drawing.Point(88, 2);
			this.PANELhome.Name = "PANELhome";
			this.PANELhome.Size = new global::System.Drawing.Size(758, 557);
			this.PANELhome.TabIndex = 54;
			this.PANELhome.Paint += new global::System.Windows.Forms.PaintEventHandler(this.guna2Panel3_Paint);
			this.guna2Panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Panel1.Controls.Add(this.label12);
			this.guna2Panel1.Controls.Add(this.guna2Button1);
			this.guna2Panel1.Controls.Add(this.label13);
			this.guna2Panel1.Controls.Add(this.label14);
			this.guna2Panel1.Controls.Add(this.label15);
			this.guna2Panel1.Controls.Add(this.label16);
			this.guna2Panel1.Location = new global::System.Drawing.Point(8, 8);
			this.guna2Panel1.Name = "guna2Panel1";
			this.guna2Panel1.Size = new global::System.Drawing.Size(0, 0);
			this.guna2Panel1.TabIndex = 58;
			this.label12.AutoSize = true;
			this.label12.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(479, 292);
			this.label12.Name = "label12";
			this.label12.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label12.Size = new global::System.Drawing.Size(126, 17);
			this.label12.TabIndex = 57;
			this.label12.Text = "MOON_VERSION";
			this.label12.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button1.BorderRadius = 3;
			this.guna2Button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button1.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button1.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button1.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button1.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button1.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button1.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button1.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button1.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button1.Name = "guna2Button1";
			this.guna2Button1.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button1.TabIndex = 53;
			this.guna2Button1.Text = "SHOW";
			this.label13.AutoSize = true;
			this.label13.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(479, 149);
			this.label13.Name = "label13";
			this.label13.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label13.Size = new global::System.Drawing.Size(173, 17);
			this.label13.TabIndex = 52;
			this.label13.Text = "MOON_CREATIONDATE";
			this.label13.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.label14.AutoSize = true;
			this.label14.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label14.ForeColor = global::System.Drawing.Color.White;
			this.label14.Location = new global::System.Drawing.Point(126, 292);
			this.label14.Name = "label14";
			this.label14.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label14.Size = new global::System.Drawing.Size(113, 17);
			this.label14.TabIndex = 52;
			this.label14.Text = "MOON_EXPIRY";
			this.label14.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.label15.AutoSize = true;
			this.label15.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label15.ForeColor = global::System.Drawing.Color.White;
			this.label15.Location = new global::System.Drawing.Point(126, 148);
			this.label15.Name = "label15";
			this.label15.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label15.Size = new global::System.Drawing.Size(155, 18);
			this.label15.TabIndex = 51;
			this.label15.Text = "MOON_USERNAME";
			this.label15.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label16.AutoSize = true;
			this.label16.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label16.ForeColor = global::System.Drawing.Color.White;
			this.label16.Location = new global::System.Drawing.Point(127, 435);
			this.label16.Name = "label16";
			this.label16.Size = new global::System.Drawing.Size(72, 19);
			this.label16.TabIndex = 51;
			this.label16.Text = "HIDDEN";
			this.createDate.AutoSize = true;
			this.createDate.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.createDate.ForeColor = global::System.Drawing.Color.White;
			this.createDate.Location = new global::System.Drawing.Point(487, 326);
			this.createDate.Name = "createDate";
			this.createDate.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.createDate.Size = new global::System.Drawing.Size(0, 17);
			this.createDate.TabIndex = 52;
			this.label29.AutoSize = true;
			this.label29.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label29.ForeColor = global::System.Drawing.Color.White;
			this.label29.Location = new global::System.Drawing.Point(133, 324);
			this.label29.Name = "label29";
			this.label29.Size = new global::System.Drawing.Size(0, 19);
			this.label29.TabIndex = 64;
			this.label29.Click += new global::System.EventHandler(this.label29_Click);
			this.label31.AutoSize = true;
			this.label31.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label31.ForeColor = global::System.Drawing.Color.White;
			this.label31.Location = new global::System.Drawing.Point(134, 466);
			this.label31.Name = "label31";
			this.label31.Size = new global::System.Drawing.Size(0, 19);
			this.label31.TabIndex = 66;
			this.label31.Click += new global::System.EventHandler(this.label31_Click);
			this.label28.AutoSize = true;
			this.label28.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label28.ForeColor = global::System.Drawing.Color.White;
			this.label28.Location = new global::System.Drawing.Point(501, 461);
			this.label28.Name = "label28";
			this.label28.Size = new global::System.Drawing.Size(0, 19);
			this.label28.TabIndex = 63;
			this.label28.Click += new global::System.EventHandler(this.label28_Click);
			this.label30.AutoSize = true;
			this.label30.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label30.ForeColor = global::System.Drawing.Color.White;
			this.label30.Location = new global::System.Drawing.Point(502, 331);
			this.label30.Name = "label30";
			this.label30.Size = new global::System.Drawing.Size(0, 19);
			this.label30.TabIndex = 65;
			this.label30.Click += new global::System.EventHandler(this.label30_Click);
			this.label27.AutoSize = true;
			this.label27.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label27.ForeColor = global::System.Drawing.Color.White;
			this.label27.Location = new global::System.Drawing.Point(184, 453);
			this.label27.Name = "label27";
			this.label27.Size = new global::System.Drawing.Size(72, 19);
			this.label27.TabIndex = 62;
			this.label27.Text = "HIDDEN";
			this.label27.Click += new global::System.EventHandler(this.label27_Click_1);
			this.guna2Button20.BorderRadius = 3;
			this.guna2Button20.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button20.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button20.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button20.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button20.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button20.FillColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.guna2Button20.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button20.ForeColor = global::System.Drawing.Color.Black;
			this.guna2Button20.Location = new global::System.Drawing.Point(490, 453);
			this.guna2Button20.Name = "guna2Button20";
			this.guna2Button20.Size = new global::System.Drawing.Size(72, 19);
			this.guna2Button20.TabIndex = 61;
			this.guna2Button20.Text = "SHOW";
			this.guna2Button20.Click += new global::System.EventHandler(this.guna2Button20_Click_2);
			this.cleanPANEL.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.cleanPANEL.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("cleanPANEL.BackgroundImage");
			this.cleanPANEL.Controls.Add(this.guna2Button19);
			this.cleanPANEL.Controls.Add(this.guna2Button18);
			this.cleanPANEL.Controls.Add(this.guna2Button16);
			this.cleanPANEL.Controls.Add(this.siticoneControlBox7);
			this.cleanPANEL.Controls.Add(this.guna2Panel3);
			this.cleanPANEL.Controls.Add(this.siticoneControlBox8);
			this.cleanPANEL.Location = new global::System.Drawing.Point(88, 2);
			this.cleanPANEL.Name = "cleanPANEL";
			this.cleanPANEL.Size = new global::System.Drawing.Size(871, 539);
			this.cleanPANEL.TabIndex = 64;
			this.cleanPANEL.Visible = false;
			this.cleanPANEL.Paint += new global::System.Windows.Forms.PaintEventHandler(this.cleanPANEL_Paint);
			this.guna2Button19.Animated = true;
			this.guna2Button19.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button19.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button19.BorderRadius = 10;
			this.guna2Button19.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button19.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button19.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button19.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button19.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button19.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button19.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button19.Location = new global::System.Drawing.Point(262, 439);
			this.guna2Button19.Name = "guna2Button19";
			this.guna2Button19.Size = new global::System.Drawing.Size(225, 36);
			this.guna2Button19.TabIndex = 61;
			this.guna2Button19.Click += new global::System.EventHandler(this.guna2Button19_Click_1);
			this.guna2Button18.Animated = true;
			this.guna2Button18.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button18.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button18.BorderRadius = 10;
			this.guna2Button18.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button18.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button18.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button18.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button18.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button18.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button18.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button18.Location = new global::System.Drawing.Point(280, 199);
			this.guna2Button18.Name = "guna2Button18";
			this.guna2Button18.Size = new global::System.Drawing.Size(191, 41);
			this.guna2Button18.TabIndex = 60;
			this.guna2Button18.Click += new global::System.EventHandler(this.guna2Button18_Click_1);
			this.guna2Button16.Animated = true;
			this.guna2Button16.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button16.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button16.BorderRadius = 10;
			this.guna2Button16.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button16.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button16.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button16.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button16.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button16.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button16.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button16.Location = new global::System.Drawing.Point(280, 130);
			this.guna2Button16.Name = "guna2Button16";
			this.guna2Button16.Size = new global::System.Drawing.Size(191, 44);
			this.guna2Button16.TabIndex = 59;
			this.guna2Button16.Click += new global::System.EventHandler(this.guna2Button16_Click_2);
			this.siticoneControlBox7.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox7.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox7.BorderColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox7.BorderRadius = 10;
			this.siticoneControlBox7.ControlBoxType = global::Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
			this.siticoneControlBox7.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox7.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.siticoneControlBox7.HoveredState.IconColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
			this.siticoneControlBox7.HoveredState.Parent = this.siticoneControlBox7;
			this.siticoneControlBox7.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox7.Location = new global::System.Drawing.Point(764, 7);
			this.siticoneControlBox7.Name = "siticoneControlBox7";
			this.siticoneControlBox7.ShadowDecoration.Parent = this.siticoneControlBox7;
			this.siticoneControlBox7.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox7.TabIndex = 57;
			this.guna2Panel3.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Panel3.Controls.Add(this.label22);
			this.guna2Panel3.Controls.Add(this.guna2Button17);
			this.guna2Panel3.Controls.Add(this.label23);
			this.guna2Panel3.Controls.Add(this.label24);
			this.guna2Panel3.Controls.Add(this.label25);
			this.guna2Panel3.Controls.Add(this.label26);
			this.guna2Panel3.Location = new global::System.Drawing.Point(8, 8);
			this.guna2Panel3.Name = "guna2Panel3";
			this.guna2Panel3.Size = new global::System.Drawing.Size(0, 0);
			this.guna2Panel3.TabIndex = 58;
			this.label22.AutoSize = true;
			this.label22.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label22.ForeColor = global::System.Drawing.Color.White;
			this.label22.Location = new global::System.Drawing.Point(479, 292);
			this.label22.Name = "label22";
			this.label22.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label22.Size = new global::System.Drawing.Size(126, 17);
			this.label22.TabIndex = 57;
			this.label22.Text = "MOON_VERSION";
			this.label22.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button17.BorderRadius = 3;
			this.guna2Button17.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button17.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button17.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button17.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button17.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button17.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button17.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button17.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button17.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button17.Name = "guna2Button17";
			this.guna2Button17.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button17.TabIndex = 53;
			this.guna2Button17.Text = "SHOW";
			this.label23.AutoSize = true;
			this.label23.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label23.ForeColor = global::System.Drawing.Color.White;
			this.label23.Location = new global::System.Drawing.Point(479, 149);
			this.label23.Name = "label23";
			this.label23.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label23.Size = new global::System.Drawing.Size(173, 17);
			this.label23.TabIndex = 52;
			this.label23.Text = "MOON_CREATIONDATE";
			this.label23.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.label24.AutoSize = true;
			this.label24.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label24.ForeColor = global::System.Drawing.Color.White;
			this.label24.Location = new global::System.Drawing.Point(126, 292);
			this.label24.Name = "label24";
			this.label24.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label24.Size = new global::System.Drawing.Size(113, 17);
			this.label24.TabIndex = 52;
			this.label24.Text = "MOON_EXPIRY";
			this.label24.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.label25.AutoSize = true;
			this.label25.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label25.ForeColor = global::System.Drawing.Color.White;
			this.label25.Location = new global::System.Drawing.Point(126, 148);
			this.label25.Name = "label25";
			this.label25.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label25.Size = new global::System.Drawing.Size(155, 18);
			this.label25.TabIndex = 51;
			this.label25.Text = "MOON_USERNAME";
			this.label25.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label26.AutoSize = true;
			this.label26.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label26.ForeColor = global::System.Drawing.Color.White;
			this.label26.Location = new global::System.Drawing.Point(127, 435);
			this.label26.Name = "label26";
			this.label26.Size = new global::System.Drawing.Size(72, 19);
			this.label26.TabIndex = 51;
			this.label26.Text = "HIDDEN";
			this.siticoneControlBox8.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox8.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox8.BorderRadius = 5;
			this.siticoneControlBox8.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox8.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(232, 17, 35);
			this.siticoneControlBox8.HoveredState.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox8.HoveredState.Parent = this.siticoneControlBox8;
			this.siticoneControlBox8.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox8.Location = new global::System.Drawing.Point(815, 7);
			this.siticoneControlBox8.Name = "siticoneControlBox8";
			this.siticoneControlBox8.ShadowDecoration.Parent = this.siticoneControlBox8;
			this.siticoneControlBox8.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox8.TabIndex = 56;
			this.SPOOFPANEL.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.SPOOFPANEL.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("SPOOFPANEL.BackgroundImage");
			this.SPOOFPANEL.Controls.Add(this.guna2Panel4);
			this.SPOOFPANEL.Controls.Add(this.guna2Button4);
			this.SPOOFPANEL.Controls.Add(this.guna2Button3);
			this.SPOOFPANEL.Location = new global::System.Drawing.Point(88, 2);
			this.SPOOFPANEL.Name = "SPOOFPANEL";
			this.SPOOFPANEL.Size = new global::System.Drawing.Size(758, 571);
			this.SPOOFPANEL.TabIndex = 59;
			this.SPOOFPANEL.Visible = false;
			this.SPOOFPANEL.Paint += new global::System.Windows.Forms.PaintEventHandler(this.SPOOFPANEL_Paint);
			this.guna2Panel4.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Panel4.Controls.Add(this.label17);
			this.guna2Panel4.Controls.Add(this.guna2Button15);
			this.guna2Panel4.Controls.Add(this.label18);
			this.guna2Panel4.Controls.Add(this.label19);
			this.guna2Panel4.Controls.Add(this.label20);
			this.guna2Panel4.Controls.Add(this.label21);
			this.guna2Panel4.Location = new global::System.Drawing.Point(8, 8);
			this.guna2Panel4.Name = "guna2Panel4";
			this.guna2Panel4.Size = new global::System.Drawing.Size(0, 0);
			this.guna2Panel4.TabIndex = 58;
			this.label17.AutoSize = true;
			this.label17.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label17.ForeColor = global::System.Drawing.Color.White;
			this.label17.Location = new global::System.Drawing.Point(479, 292);
			this.label17.Name = "label17";
			this.label17.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label17.Size = new global::System.Drawing.Size(126, 17);
			this.label17.TabIndex = 57;
			this.label17.Text = "MOON_VERSION";
			this.label17.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button15.BorderRadius = 3;
			this.guna2Button15.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button15.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button15.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button15.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button15.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button15.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button15.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button15.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button15.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button15.Name = "guna2Button15";
			this.guna2Button15.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button15.TabIndex = 53;
			this.guna2Button15.Text = "SHOW";
			this.label18.AutoSize = true;
			this.label18.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label18.ForeColor = global::System.Drawing.Color.White;
			this.label18.Location = new global::System.Drawing.Point(479, 149);
			this.label18.Name = "label18";
			this.label18.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label18.Size = new global::System.Drawing.Size(173, 17);
			this.label18.TabIndex = 52;
			this.label18.Text = "MOON_CREATIONDATE";
			this.label18.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.label19.AutoSize = true;
			this.label19.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label19.ForeColor = global::System.Drawing.Color.White;
			this.label19.Location = new global::System.Drawing.Point(126, 292);
			this.label19.Name = "label19";
			this.label19.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label19.Size = new global::System.Drawing.Size(113, 17);
			this.label19.TabIndex = 52;
			this.label19.Text = "MOON_EXPIRY";
			this.label19.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.label20.AutoSize = true;
			this.label20.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label20.ForeColor = global::System.Drawing.Color.White;
			this.label20.Location = new global::System.Drawing.Point(126, 148);
			this.label20.Name = "label20";
			this.label20.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label20.Size = new global::System.Drawing.Size(155, 18);
			this.label20.TabIndex = 51;
			this.label20.Text = "MOON_USERNAME";
			this.label20.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label21.AutoSize = true;
			this.label21.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label21.ForeColor = global::System.Drawing.Color.White;
			this.label21.Location = new global::System.Drawing.Point(127, 435);
			this.label21.Name = "label21";
			this.label21.Size = new global::System.Drawing.Size(72, 19);
			this.label21.TabIndex = 51;
			this.label21.Text = "HIDDEN";
			this.guna2Button7.Animated = true;
			this.guna2Button7.AnimatedGIF = true;
			this.guna2Button7.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.guna2Button7.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.BorderRadius = 5;
			this.guna2Button7.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.guna2Button7.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button7.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button7.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button7.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button7.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button7.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.FocusedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.guna2Button7.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button7.ForeColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.guna2Button7.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("guna2Button7.Image");
			this.guna2Button7.Location = new global::System.Drawing.Point(27, 524);
			this.guna2Button7.Name = "guna2Button7";
			this.guna2Button7.PressedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.guna2Button7.Size = new global::System.Drawing.Size(35, 35);
			this.guna2Button7.TabIndex = 55;
			this.guna2Button7.UseTransparentBackground = true;
			this.guna2Button7.Click += new global::System.EventHandler(this.guna2Button7_Click_1);
			this.cleanBTN.Animated = true;
			this.cleanBTN.AnimatedGIF = true;
			this.cleanBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.cleanBTN.BorderColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.BorderRadius = 5;
			this.cleanBTN.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.cleanBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.cleanBTN.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.cleanBTN.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.cleanBTN.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.cleanBTN.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.cleanBTN.FillColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.FocusedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.cleanBTN.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.cleanBTN.ForeColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.cleanBTN.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cleanBTN.Image");
			this.cleanBTN.Location = new global::System.Drawing.Point(27, 349);
			this.cleanBTN.Name = "cleanBTN";
			this.cleanBTN.PressedColor = global::System.Drawing.Color.FromArgb(187, 2, 0);
			this.cleanBTN.Size = new global::System.Drawing.Size(35, 35);
			this.cleanBTN.TabIndex = 56;
			this.cleanBTN.UseTransparentBackground = true;
			this.cleanBTN.Click += new global::System.EventHandler(this.guna2Button16_Click_1);
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(12, 24);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(62, 55);
			this.pictureBox1.TabIndex = 60;
			this.pictureBox1.TabStop = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.AutoValidate = global::System.Windows.Forms.AutoValidate.Disable;
			this.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 9);
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			base.ClientSize = new global::System.Drawing.Size(960, 585);
			base.Controls.Add(this.cleanPANEL);
			base.Controls.Add(this.SPOOFPANEL);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.cleanBTN);
			base.Controls.Add(this.guna2Button7);
			base.Controls.Add(this.siticoneControlBox1);
			base.Controls.Add(this.siticoneControlBox2);
			base.Controls.Add(this.settingsBTN);
			base.Controls.Add(this.homeBTN);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.PANELhome);
			this.DoubleBuffered = true;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Main";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = " ";
			base.TransparencyKey = global::System.Drawing.Color.Maroon;
			this.PANELhome.ResumeLayout(false);
			this.PANELhome.PerformLayout();
			this.guna2Panel1.ResumeLayout(false);
			this.guna2Panel1.PerformLayout();
			this.cleanPANEL.ResumeLayout(false);
			this.guna2Panel3.ResumeLayout(false);
			this.guna2Panel3.PerformLayout();
			this.SPOOFPANEL.ResumeLayout(false);
			this.guna2Panel4.ResumeLayout(false);
			this.guna2Panel4.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000013 RID: 19
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000014 RID: 20
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000015 RID: 21
		private global::Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;

		// Token: 0x04000016 RID: 22
		private global::Guna.UI2.WinForms.Guna2Button settingsBTN;

		// Token: 0x04000017 RID: 23
		private global::Guna.UI2.WinForms.Guna2Button homeBTN;

		// Token: 0x04000018 RID: 24
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox1;

		// Token: 0x04000019 RID: 25
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox2;

		// Token: 0x0400001A RID: 26
		private global::Guna.UI2.WinForms.Guna2Button guna2Button3;

		// Token: 0x0400001B RID: 27
		private global::Guna.UI2.WinForms.Guna2Button guna2Button4;

		// Token: 0x0400001C RID: 28
		private global::Siticone.UI.WinForms.SiticoneLabel key;

		// Token: 0x0400001D RID: 29
		private global::Siticone.UI.WinForms.SiticoneLabel subscriptionDaysLabel;

		// Token: 0x0400001E RID: 30
		private global::System.Windows.Forms.Label hwidlabel;

		// Token: 0x0400001F RID: 31
		private global::Guna.UI2.WinForms.Guna2Panel PANELhome;

		// Token: 0x04000020 RID: 32
		private global::Guna.UI2.WinForms.Guna2Button guna2Button7;

		// Token: 0x04000021 RID: 33
		private global::Guna.UI2.WinForms.Guna2Button guna2Button6;

		// Token: 0x04000022 RID: 34
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel1;

		// Token: 0x04000023 RID: 35
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000024 RID: 36
		private global::Guna.UI2.WinForms.Guna2Button guna2Button1;

		// Token: 0x04000025 RID: 37
		private global::System.Windows.Forms.Label label13;

		// Token: 0x04000026 RID: 38
		private global::System.Windows.Forms.Label label14;

		// Token: 0x04000027 RID: 39
		private global::System.Windows.Forms.Label label15;

		// Token: 0x04000028 RID: 40
		private global::System.Windows.Forms.Label label16;

		// Token: 0x04000029 RID: 41
		private global::Guna.UI2.WinForms.Guna2Panel SPOOFPANEL;

		// Token: 0x0400002A RID: 42
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel4;

		// Token: 0x0400002B RID: 43
		private global::System.Windows.Forms.Label label17;

		// Token: 0x0400002C RID: 44
		private global::Guna.UI2.WinForms.Guna2Button guna2Button15;

		// Token: 0x0400002D RID: 45
		private global::System.Windows.Forms.Label label18;

		// Token: 0x0400002E RID: 46
		private global::System.Windows.Forms.Label label19;

		// Token: 0x0400002F RID: 47
		private global::System.Windows.Forms.Label label20;

		// Token: 0x04000030 RID: 48
		private global::System.Windows.Forms.Label label21;

		// Token: 0x04000031 RID: 49
		private global::Guna.UI2.WinForms.Guna2Button cleanBTN;

		// Token: 0x04000032 RID: 50
		private global::Guna.UI2.WinForms.Guna2Panel cleanPANEL;

		// Token: 0x04000033 RID: 51
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox7;

		// Token: 0x04000034 RID: 52
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel3;

		// Token: 0x04000035 RID: 53
		private global::System.Windows.Forms.Label label22;

		// Token: 0x04000036 RID: 54
		private global::Guna.UI2.WinForms.Guna2Button guna2Button17;

		// Token: 0x04000037 RID: 55
		private global::System.Windows.Forms.Label label23;

		// Token: 0x04000038 RID: 56
		private global::System.Windows.Forms.Label label24;

		// Token: 0x04000039 RID: 57
		private global::System.Windows.Forms.Label label25;

		// Token: 0x0400003A RID: 58
		private global::System.Windows.Forms.Label label26;

		// Token: 0x0400003B RID: 59
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox8;

		// Token: 0x0400003C RID: 60
		private global::Guna.UI2.WinForms.Guna2Button guna2Button18;

		// Token: 0x0400003D RID: 61
		private global::Guna.UI2.WinForms.Guna2Button guna2Button16;

		// Token: 0x0400003E RID: 62
		private global::Guna.UI2.WinForms.Guna2Button guna2Button19;

		// Token: 0x0400003F RID: 63
		private global::System.Windows.Forms.Label createDate;

		// Token: 0x04000040 RID: 64
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.Label label27;

		// Token: 0x04000042 RID: 66
		private global::Guna.UI2.WinForms.Guna2Button guna2Button20;

		// Token: 0x04000043 RID: 67
		private global::System.Windows.Forms.Label label28;

		// Token: 0x04000044 RID: 68
		private global::System.Windows.Forms.Label label29;

		// Token: 0x04000045 RID: 69
		private global::System.Windows.Forms.Label label31;

		// Token: 0x04000046 RID: 70
		private global::System.Windows.Forms.Label label30;
	}
}
