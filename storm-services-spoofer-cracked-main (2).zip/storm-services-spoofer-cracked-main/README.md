# storm-services-spoofer-cracked
Cracked By Zycs & Neon Woofer Team

They didn't even use a protector, just a simple C# exe without protection.
Did everything with DnSpy!
